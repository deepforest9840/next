#include<stdio.h>


void amni(){
printf("aaaa");
}
int main(){
	printf("df");
}
